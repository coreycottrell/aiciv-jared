# app.purebrain.ai — Full Repository Package
**Date**: 2026-03-04
**From**: Aether Engineering Team (PureBrain.ai)

---

## Architecture Overview

```
Internet → Cloudflare Tunnel → nginx:8099 → Portal Server:8097
                                    ↓
                              Customer subdomains
                              (keenjared.purebrain.ai → Witness containers)
```

### Domain Routing
| Domain | Destination |
|--------|-------------|
| `portal.purebrain.ai` | Admin portal (Starlette on port 8097) |
| `app.purebrain.ai` | 301 redirect → portal.purebrain.ai |
| `api.purebrain.ai` | API/Log server (HTTPS port 8443) |
| `*.purebrain.ai` | Customer portals → nginx dynamic router → Witness containers |

---

## Directory Structure

```
app-purebrain-ai-full-repo/
├── portal-server/          # Core portal application
│   ├── portal_server.py    # Starlette server (REST API + WebSocket + HTML)
│   ├── portal.html         # Original dark theme portal UI
│   ├── portal-pb-styled.html # PureBrain-branded portal UI (production)
│   ├── start.sh            # Launch script (port 8097)
│   ├── portal-token.example # Auth token template
│   ├── PORTAL-SETUP-GUIDE.md
│   └── INFRA-NOTES.md
│
├── api-server/             # API + webhook handler
│   ├── purebrain_log_server.py  # Birth webhook, seed proxy, portal-status
│   └── launch_purebrain_log_server.sh
│
├── nginx/                  # Reverse proxy configs
│   ├── purebrain-main.conf           # portal.purebrain.ai → :8097
│   └── purebrain-customer-portals.conf # Customer subdomain routing
│
├── cloudflare/             # Tunnel configuration
│   └── cloudflared-config.yml  # Ingress rules for *.purebrain.ai
│
├── systemd/                # Auto-start service
│   └── aether-portal.service   # Portal server systemd unit
│
├── tools/                  # Infrastructure automation
│   ├── subdomain_router.py      # Auto-generates nginx configs + DNS
│   ├── patch_portal_favicon.py  # Injects PureBrain branding
│   └── patch_birth_webhook.py   # Sets up birth webhook endpoint
│
├── assets/                 # Brand assets
│   ├── favicon.ico         # 16x16 favicon
│   ├── favicon-32.png      # 32x32 PNG favicon
│   ├── icon-192.png        # PWA icon (192x192)
│   └── apple-touch-icon.png # iOS icon (180x180)
│
└── docs/                   # Documentation
    ├── witness-integration-spec-2026-03-04-v2.md  # Full Witness↔Aether spec
    └── purebrain_routes.json  # Customer route database
```

---

## Portal Server (port 8097)

### Endpoints
| Path | Method | Purpose |
|------|--------|---------|
| `/` | GET | Original dark theme portal |
| `/pb` | GET | PureBrain-styled portal (production) |
| `/react` | GET | React variant |
| `/api/status` | GET | Server health check |
| `/api/chat/history` | GET | Chat history (JSONL) |
| `/api/chat/send` | POST | Send chat message |
| `/ws/terminal?token=TOKEN` | WebSocket | Live terminal stream |
| `/ws/chat?token=TOKEN` | WebSocket | Real-time chat |
| `/favicon.ico` | GET | Serve favicon |

### Authentication
Bearer token from `.portal-token` file. Required for all API/WS endpoints.

### Launch
```bash
cd /home/jared/purebrain_portal
./start.sh  # Defaults to port 8097
# OR
python3 portal_server.py --port 8097
```

---

## API Server (purebrain_log_server.py)

### Key Endpoints
| Endpoint | Method | Purpose |
|----------|--------|---------|
| `/api/birth/webhook` | POST | Receive birth_complete from Witness |
| `/api/birth/portal-status/{container}` | GET | Chatbox polls for portal readiness |
| `/api/intake/seed` | POST | Proxy seed to Witness (178.156.229.207:8200) |
| `/api/verify-payment` | POST | PayPal payment verification |
| `/api/spots-status` | GET | Available spots counter |

### Birth Complete Webhook
When Witness fires `POST /api/birth/webhook`:
1. Validates auth (`X-Witness-Secret: witness-secret-2026`)
2. Derives subdomain: `keen` + `jared` → `keenjared`
3. Creates Cloudflare DNS CNAME
4. Creates nginx reverse proxy config
5. Rewrites magic link to purebrain.ai domain
6. Sends customer email (Brevo template 30)
7. Notifies Jared via Telegram

---

## Infrastructure Flow

### New Customer Birth Pipeline
```
Customer pays on purebrain.ai
  └→ Post-payment chatbox opens
  └→ Collects: name, AI name, preferences, 5+ messages
  └→ fireSeed() → POST /api/intake/seed → Witness
  └→ Witness processes seed (3-5 min)
  └→ Witness fires POST /api/birth/webhook
  └→ Auto-provision: DNS + nginx + magic link rewrite
  └→ Chatbox button lights up: "ENTER [AI NAME]'S BRAIN STREAM"
  └→ Customer clicks → lands on keenjared.purebrain.ai
  └→ OAuth happens in portal → AI is alive
```

### Auto-Provisioning (subdomain_router.py)
When a new customer is born:
1. Generates subdomain: `{ainame}{firstname}` (lowercase, alphanumeric only)
2. Creates Cloudflare DNS CNAME via API
3. Generates nginx server block
4. Reloads nginx
5. Updates `purebrain_routes.json`

---

## Ports Summary
| Port | Service | Notes |
|------|---------|-------|
| 8097 | Portal Starlette server | Customer portal UI |
| 8099 | nginx reverse proxy | Receives from Cloudflare tunnel |
| 8443 | API/Log server (HTTPS) | Birth webhooks, seed proxy |
| 8200 | Witness intake (external) | 178.156.229.207:8200 |
| 8765 | Video management GUI | video.purebrain.ai |
| 8870 | Command Center | cc.purebrain.ai |

---

## Customer Subdomain Format
- Pattern: `{ainame}{firstname}.purebrain.ai`
- Rules: lowercase, alphanumeric only, no hyphens/spaces
- Example: AI "Keen" + Human "Jared Sanborn" → `keenjared.purebrain.ai`
- Duplicates: append number (`keenjared2`, `keenjared3`)
- Max 63 chars (DNS limit)

---

## Deployment
```bash
# Install systemd service
sudo cp systemd/aether-portal.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable aether-portal
sudo systemctl start aether-portal

# Install nginx configs
sudo cp nginx/*.conf /etc/nginx/conf.d/
sudo nginx -t && sudo systemctl reload nginx

# Install cloudflare tunnel config
sudo cp cloudflare/cloudflared-config.yml /etc/cloudflared/config.yml
sudo systemctl restart cloudflared
```

---

*Generated by Aether Engineering Team — 2026-03-04*
