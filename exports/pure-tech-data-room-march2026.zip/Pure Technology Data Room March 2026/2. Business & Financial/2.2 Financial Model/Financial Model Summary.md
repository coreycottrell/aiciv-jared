# Pure Technology Inc. — Financial Model Summary
## 5-Year Projections | March 2026

**Prepared**: March 2026
**Source of Truth**: PT-Full-Financial-Model-WITH-PureBrainFINISHED.xlsx (uploaded March 19, 2026)
**Classification**: Investor Data Room — Financial Overview

---

## HEADLINE NUMBERS

| Metric | Value |
|--------|-------|
| Year 1 Total Revenue | $3.962B |
| Year 5 Total Revenue | $72.698B |
| 5-Year Cumulative Revenue | ~$156B |
| Year 5 EBITDA | $52.374B (72% margin) |
| PureBrain Gross Margin (Year 5) | 87.9% |
| Active Subscribers (Year 5) | 12,900,000 |
| Blended ARPU | $345/month (constant) |
| LTV:CAC at Scale | 225:1 (Year 3) → 550:1 (Year 5) |
| Team Headcount | Hard cap 100; currently 48 |

---

## CONSOLIDATED P&L (5-YEAR)

### Revenue by Stream

| Revenue Stream | Year 0 | Year 1 | Year 2 | Year 3 | Year 4 | Year 5 |
|---------------|--------|--------|--------|--------|--------|--------|
| **PureBrain** | **$441.8M** | **$3.500B** | **$5.400B** | **$15.300B** | **$33.500B** | **$50.700B** |
| Hardware Subsidies | $9.9M | $198.8M | $1.285B | $2.051B | $2.849B | $3.680B |
| Market Research / Core | $0 | $167.2M | $1.442B | $4.364B | $9.650B | $14.942B |
| Pure Influence | $259K | $7.2M | $39.2M | $161.8M | $406.4M | $886.9M |
| CPG Model | $5.5M | $71.1M | $244.9M | $645.2M | $1.502B | $2.423B |
| Camera Commerce | $2.6M | $17.4M | $32.4M | $58.2M | $104.5M | $65.2M |
| Pure Research | $65K | $280K | $475K | $672K | $944K | $1.2M |
| **TOTAL CONSOLIDATED** | **$460.1M** | **$3.962B** | **$8.443B** | **$22.581B** | **$48.013B** | **$72.698B** |

### EBITDA Summary

| Year | Total Revenue | EBITDA | EBITDA Margin |
|------|-------------|--------|-------------|
| Year 0 | $460.1M | $328.4M | 71.4% |
| Year 1 | $3.962B | $2.953B | 74.5% |
| Year 2 | $8.443B | $5.065B | 60.0% |
| Year 3 | $22.581B | $14.920B | 66.1% |
| Year 4 | $48.013B | $33.920B | 70.6% |
| Year 5 | $72.698B | $52.374B | 72.1% |

---

## PUREBRAIN DETAILED MODEL

### Subscriber Growth

| Period | Active Subscribers | Monthly New Subscribers | Monthly Churn |
|--------|------------------|----------------------|--------------|
| Year 0 (Pre-Launch) | 420,000 | — | 4.2% |
| Year 1 End | 1,200,000 | 75,000 | 3.5% |
| Year 2 End | 2,200,000 | 90,000 | 3.5% |
| Year 3 End | 5,400,000 | 220,000 | 3.0% |
| Year 4 End | 9,400,000 | 380,000 | 2.8% |
| Year 5 End | 12,900,000 | 440,000 | 2.5% |

### PureBrain Revenue Breakdown

| Revenue Type | Year 0 | Year 1 | Year 2 | Year 3 | Year 4 | Year 5 |
|-------------|--------|--------|--------|--------|--------|--------|
| Consumer Subscriptions | $436.8M | $3.300B | $4.860B | $13.770B | $29.750B | $43.200B |
| Enterprise Revenue | $5.0M | $200M | $540M | $1.530B | $3.750B | $7.500B |
| **Total PureBrain** | **$441.8M** | **$3.500B** | **$5.400B** | **$15.300B** | **$33.500B** | **$50.700B** |

### PureBrain Margins

| Metric | Year 0 | Year 1 | Year 2 | Year 3 | Year 4 | Year 5 |
|--------|--------|--------|--------|--------|--------|--------|
| Gross Margin % | 78.9% | 82.6% | 83.0% | 85.0% | 86.5% | 87.9% |
| EBITDA Margin % | 78.8% | 82.5% | 82.8% | 84.9% | 86.4% | 87.8% |
| Team Headcount | 0 | 2 | 4 | 6 | 8 | 10 |

**Why margins improve with scale**: AI infrastructure cost per user drops 30–40% per 10x scale due to bulk pricing, model optimization, and Cloudflare serverless economics.

---

## UNIT ECONOMICS

### Customer Acquisition Cost

| Period | Blended CAC |
|--------|------------|
| Year 0 (Launch) | $150 |
| Year 1 | $45 |
| Year 2 | $45 |
| Year 3 | $20 |
| Year 4 | $15 |
| Year 5 | $12 |

**CAC reduction drivers**: Viral referral loop (Brainiac Mastermind cohort model), True Bearing partnership warm leads, organic content marketing (building in public), word-of-mouth from memory moat.

### Lifetime Value by Tier

| Tier | Monthly Price | Monthly Churn | Avg Lifetime | LTV |
|------|-------------|--------------|-------------|-----|
| Awakened | $197/mo | 4.5% | 22 months | $4,334 |
| Partnered | $579/mo | 3.0% | 33 months | $19,107 |
| Unified | $1,089/mo | 2.0% | 50 months | $54,450 |
| Enterprise | $10,000/mo avg | 1.5% | 67 months | $670,000 |

### LTV:CAC Progression

| Year | LTV:CAC | Interpretation |
|------|---------|---------------|
| Year 0 (Launch) | 28:1 | Excellent for new product |
| Year 1 | 92:1 | Exceptional |
| Year 2 | 92:1 | Exceptional |
| Year 3 | 225:1 | Best-in-class |
| Year 4 | 350:1 | Category-defining |
| Year 5 | 550:1 | Unprecedented |

**Benchmark**: SaaS companies with LTV:CAC above 3:1 are considered healthy. Above 10:1 is exceptional. PureBrain's model projects 225:1 by Year 3.

### Blended ARPU (Consumer)

| Tier | % of Subscribers | Monthly Price | ARPU Contribution |
|------|----------------|-------------|-----------------|
| Awakened | 72% | $197 | $141.84 |
| Partnered | 20% | $579 | $115.80 |
| Unified | 8% | $1,089 | $87.12 |
| **Blended Consumer ARPU** | **100%** | — | **$344.76** |

---

## INFRASTRUCTURE COST MODEL (PUREBRAIN)

As subscriber count grows, per-user infrastructure cost drops dramatically:

| Active Users | Monthly AI/Infra Cost | Per-User Cost | Gross Margin |
|-------------|----------------------|------------|------------|
| 100 | $2,500 | $25.00 | ~87% |
| 1,000 | $18,000 | $18.00 | ~89% |
| 10,000 | $120,000 | $12.00 | ~91% |
| 100,000 | $700,000 | $7.00 | ~93% |
| 1,000,000 | $3,500,000 | $3.50 | ~95% |
| 5,000,000+ | $12,000,000 | $2.40 | ~96% |

---

## HEADCOUNT MODEL

**Hard cap**: 100 employees (enforced by design)
**Current headcount**: 48 (March 2026)
**PureBrain team**: 0 (pre-launch) → 10 by Year 5

The inability to scale headcount linearly is an architectural constraint that forces AI-first operations and keeps margins at 78%+ EBITDA. This is not a limitation — it is the moat.

At Year 5: $72.7B revenue with under 100 people = ~$727M revenue per employee.

| Period | Total Headcount | PureBrain Team | PT Core Team |
|--------|----------------|---------------|-------------|
| Now (March 2026) | 48 | 0 | 48 |
| Year 1 End | 55 | 2 | 53 |
| Year 2 End | 65 | 4 | 61 |
| Year 3 End | 80 | 6 | 74 |
| Year 5 End | 100 | 10 | 90 |

---

## HISTORICAL FINANCIALS (PRE-PUREBRAIN)

| Period | Revenue | Notes |
|--------|---------|-------|
| 2022 | $20,130 | Pre-scale PMG |
| 2023 | $943,136 | PMG agency revenue (Equidam, Dec 2023) |
| 2023 EBITDA | $68,136 | |
| Early 2024 PMG Base | $77,609 | Recurring client revenue |
| Early 2024 Pipeline | $118,050 | Pending deals |

**Equity round history**: May 2023 — Post-money valuation $15,734,684; Investment $734,684; Equity 5.65%

---

## FINANCIAL ASSUMPTIONS (KEY)

| Assumption | Value | Notes |
|-----------|-------|-------|
| PureBrain ARPU | $345/mo | Blended consumer; constant across 5 years |
| PureBrain Enterprise Average | $10,000/mo | Scales to $25,000 at Year 5 |
| Blended CAC (launch) | $150 | Declines to $12 by Year 5 |
| Monthly Churn (launch) | 4.2% | Declines to 2.5% by Year 5 |
| Infrastructure Cost per User | $25 → $2.40 | Drops with scale |
| Team Hard Cap | 100 | Enforced architecturally |

---

## VALUATION CONTEXT

| Scenario | Basis | Implied Valuation |
|----------|-------|-----------------|
| MAKR Term Sheet (2025) | DiMAP model only | $105M pre / $130M post |
| Year 1 ARR × 5x (conservative) | $2.24B ARR | $11.2B |
| Year 1 ARR × 10x (SaaS median) | $2.24B ARR | $22.4B |
| Year 5 Revenue × 3x | $72.7B | $218B |
| Year 5 EBITDA × 20x | $52.4B | $1.05T |

**Note**: The MAKR term sheet predates PureBrain's commercial launch. Valuation should be re-evaluated in context of the new model and live traction.

---

*Pure Technology Inc. | March 2026 | Investor Data Room*
*Source: PT-Full-Financial-Model-WITH-PureBrainFINISHED.xlsx (March 19, 2026)*
