# Pure Technology Inc. — Revenue Projections by Division
## All Six Divisions | 5-Year Forecast | March 2026

**Prepared**: March 2026
**Source**: PT-Full-Financial-Model-WITH-PureBrainFINISHED.xlsx (March 19, 2026)
**Classification**: Investor Data Room — Revenue Detail

---

## CONSOLIDATED REVENUE SUMMARY

| Revenue Stream | Year 0 | Year 1 | Year 2 | Year 3 | Year 4 | Year 5 |
|---------------|--------|--------|--------|--------|--------|--------|
| PureBrain | $441.8M | $3.500B | $5.400B | $15.300B | $33.500B | $50.700B |
| Hardware Subsidies | $9.9M | $198.8M | $1.285B | $2.051B | $2.849B | $3.680B |
| Market Research / Core | $0 | $167.2M | $1.442B | $4.364B | $9.650B | $14.942B |
| Pure Influence | $259K | $7.2M | $39.2M | $161.8M | $406.4M | $886.9M |
| CPG Model | $5.5M | $71.1M | $244.9M | $645.2M | $1.502B | $2.423B |
| Camera Commerce | $2.6M | $17.4M | $32.4M | $58.2M | $104.5M | $65.2M |
| Pure Research | $65K | $280K | $475K | $672K | $944K | $1.2M |
| **TOTAL** | **$460.1M** | **$3.962B** | **$8.443B** | **$22.581B** | **$48.013B** | **$72.698B** |

**PureBrain % of Total Revenue**:
- Year 0: 96%
- Year 1: 88%
- Year 2: 64%
- Year 3: 68%
- Year 4: 70%
- Year 5: 70%

---

## DIVISION 1: PUREBRAIN

PureBrain is the primary revenue engine. Its SaaS economics dominate the consolidated model by Year 1.

### Revenue Breakdown

| Component | Year 0 | Year 1 | Year 2 | Year 3 | Year 4 | Year 5 |
|-----------|--------|--------|--------|--------|--------|--------|
| Consumer Subscriptions | $436.8M | $3.300B | $4.860B | $13.770B | $29.750B | $43.200B |
| Enterprise Revenue | $5.0M | $200M | $540M | $1.530B | $3.750B | $7.500B |
| **Total PureBrain** | **$441.8M** | **$3.500B** | **$5.400B** | **$15.300B** | **$33.500B** | **$50.700B** |

### Subscriber Metrics

| Metric | Year 0 | Year 1 | Year 2 | Year 3 | Year 4 | Year 5 |
|--------|--------|--------|--------|--------|--------|--------|
| End of Year Subscribers | 420,000 | 1,200,000 | 2,200,000 | 5,400,000 | 9,400,000 | 12,900,000 |
| Blended Consumer ARPU | $345/mo | $345/mo | $345/mo | $345/mo | $345/mo | $345/mo |
| Monthly Churn | 4.2% | 3.5% | 3.5% | 3.0% | 2.8% | 2.5% |
| Gross Margin | 78.9% | 82.6% | 83.0% | 85.0% | 86.5% | 87.9% |

### Pricing Tier Contribution

| Tier | Price | Users (% mix) | Year 1 Revenue |
|------|-------|-------------|---------------|
| Awakened (Bonded) | $197/mo | 72% | ~$2.04B |
| Partnered | $579/mo | 20% | ~$835M |
| Unified | $1,089/mo | 8% | ~$396M |
| Enterprise | $10K–$25K/mo avg | Separate count | $200M |

---

## DIVISION 2: HARDWARE SUBSIDIES (PURE PHONE / DIMAP)

Hardware revenue comes from brands paying to subsidize phone distribution in exchange for complete consumer profile data access.

| Metric | Year 0 | Year 1 | Year 2 | Year 3 | Year 4 | Year 5 |
|--------|--------|--------|--------|--------|--------|--------|
| Revenue | $9.9M | $198.8M | $1.285B | $2.051B | $2.849B | $3.680B |
| Phones Deployed (approx.) | — | ~191K | ~1.28M | ~2.44M | ~3.67M | ~5.06M |

**Revenue driver**: Brands pay per-phone subsidy in exchange for complete consumer data access. Subsidy amount increases as user engagement data value is proven.

---

## DIVISION 3: MARKET RESEARCH / CORE PLATFORM

The DiMAP market research platform generates revenue from brands commissioning consumer studies, focus groups, surveys, and mystery shopping via the Pure Phone user base.

| Study Type | Revenue Per User/Year | Year 1 Revenue |
|-----------|----------------------|---------------|
| Focus Groups | $832 | — |
| Mystery Shopping | $400 | — |
| Consumer Experience Studies | $187.50 | — |
| Surveys & Questionnaires | $100 | — |
| Predictive Problem Solving | $85.39 | — |
| **Total Market Research** | **~$1,520/user/year** | **$167.2M** |

| Year | Revenue |
|------|---------|
| Year 0 | $0 (pre-launch) |
| Year 1 | $167.2M |
| Year 2 | $1.442B |
| Year 3 | $4.364B |
| Year 4 | $9.650B |
| Year 5 | $14.942B |

---

## DIVISION 4: PURE INFLUENCE

Intelligent influencer marketing platform. Revenue from brand campaigns, platform SaaS fees, and influencer marketplace transactions.

| Year | Revenue | Notes |
|------|---------|-------|
| Year 0 | $259K | Pre-launch tests |
| Year 1 | $7.2M | Platform launch; 1K+ influencers live |
| Year 2 | $39.2M | Expanding brand client base |
| Year 3 | $161.8M | Network effect building |
| Year 4 | $406.4M | Scale phase |
| Year 5 | $886.9M | Mature platform |

**Growth rate**: ~50% CAGR Year 1–5
**Key assets at launch**: 1,000+ influencers with 1B+ combined followers pre-vetted
**Pending partnerships**: Warner Music Group, Forbes, UFC

---

## DIVISION 5: CPG MODEL

Consumer packaged goods brands subsidize phone distribution through product partnerships. Revenue from CPG brand payments for phone distribution and user data access.

| Year | Revenue | Monthly Phone Units |
|------|---------|-------------------|
| Year 0 | $5.5M | 3,000 |
| Year 1 | $71.1M | ~5,100 |
| Year 2 | $244.9M | ~9,200 |
| Year 3 | $645.2M | ~16,500 |
| Year 4 | $1.502B | ~30,000 |
| Year 5 | $2.423B | ~50,000+ |

**CPG Strategy**: Pure Phone distributed through CPG packaging — consumers opt-in through brand partnerships, creating a warm, brand-affiliated user base.

---

## DIVISION 6: CAMERA COMMERCE (PURE SHOPPING)

Pure Shopping uses smartphone camera technology to enable product purchase through visual scanning — no barcodes or QR codes required.

| Year | Revenue |
|------|---------|
| Year 0 | $2.6M |
| Year 1 | $17.4M |
| Year 2 | $32.4M |
| Year 3 | $58.2M |
| Year 4 | $104.5M |
| Year 5 | $65.2M |

---

## DIVISION 7: PURE RESEARCH

Data intelligence, research services, and market insights.

| Year | Revenue |
|------|---------|
| Year 0 | $65K |
| Year 1 | $280K |
| Year 2 | $475K |
| Year 3 | $672K |
| Year 4 | $944K |
| Year 5 | $1.2M |

---

## REVENUE GROWTH RATES

| Year | Total Revenue | YoY Growth |
|------|-------------|-----------|
| Year 0 | $460.1M | — |
| Year 1 | $3.962B | 761% |
| Year 2 | $8.443B | 113% |
| Year 3 | $22.581B | 168% |
| Year 4 | $48.013B | 113% |
| Year 5 | $72.698B | 51% |

**5-Year CAGR**: ~174% (Year 0 to Year 5)

---

## COMPARISON: OLD MODEL VS. NEW MODEL

| Metric | Old Board View (2025) | New Consolidated Model (2026) | Difference |
|--------|----------------------|------------------------------|----------|
| Year 1 Revenue | $253.8M | $3.962B | +15.6x |
| Year 5 Revenue | $13.28B | $72.698B | +5.5x |
| Year 0 Revenue | $3.5M | $460.1M | +131x |
| Primary Driver | Phone deployment | PureBrain SaaS | New engine |

**Context**: The old model did not include PureBrain. PureBrain was added to the consolidated model in March 2026 following its commercial launch.

---

*Pure Technology Inc. | March 2026 | Investor Data Room*
*Source: PT-Full-Financial-Model-WITH-PureBrainFINISHED.xlsx (March 19, 2026)*
