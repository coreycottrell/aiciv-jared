# Pure Technology Inc. — Unit Economics
## PureBrain SaaS Model | March 2026

**Prepared**: March 2026
**Classification**: Investor Data Room — Unit Economics

---

## HEADLINE UNIT ECONOMICS

| Metric | At Launch | Year 1 | Year 3 (Steady State) |
|--------|----------|--------|----------------------|
| Blended ARPU | $345/mo | $345/mo | $345/mo |
| Blended CAC | $150 | $45 | $20 |
| LTV:CAC | 28:1 | 92:1 | 225:1 |
| Gross Margin | 78.9% | 82.6% | 85.0% |
| EBITDA Margin | 78.8% | 82.5% | 84.9% |
| Monthly Churn | 4.2% | 3.5% | 3.0% |
| Payback Period | ~1.3 months | ~0.4 months | ~0.2 months |

---

## AVERAGE REVENUE PER USER (ARPU)

### Consumer Tier Blending

PureBrain's blended consumer ARPU is calculated from the weighted average of three subscription tiers:

| Tier | Monthly Price | Annual Price | User % Mix | ARPU Contribution |
|------|-------------|-------------|-----------|-----------------|
| Awakened (Bonded) | $197/mo | $2,364/yr | 72% | $141.84 |
| Partnered | $579/mo | $6,948/yr | 20% | $115.80 |
| Unified | $1,089/mo | $13,068/yr | 8% | $87.12 |
| **Blended Consumer ARPU** | — | — | **100%** | **$344.76** |

### Enterprise ARPU

- Current average: $10,000/month ($120K/year)
- Range: $3,500–$25,000/month
- Year 5 average: $25,000/month as contract complexity grows
- Enterprise = separate count from consumer subscriptions

### Annual Recurring Revenue (ARR) per Subscriber Cohort

| Tier | Monthly Price | ARR per User |
|------|-------------|-------------|
| Awakened | $197 | $2,364 |
| Partnered | $579 | $6,948 |
| Unified | $1,089 | $13,068 |
| Enterprise | $10,000 avg | $120,000 |

---

## CUSTOMER ACQUISITION COST (CAC)

### CAC by Channel

| Channel | CAC | Notes |
|---------|-----|-------|
| Brainiac Mastermind referral | ~$20 | Cohort members invite peers; nearly zero paid spend |
| Organic / Building in Public | ~$15 | LinkedIn, Bluesky content drives sign-ups |
| True Bearing partnership | ~$30 | Warm referrals from Corey Cottrell's 100K+ network |
| Paid acquisition | ~$200 | Modeled as launch fallback; rarely used |
| **Blended CAC (launch)** | **$150** | Includes paid launch spike |
| **Blended CAC (Year 3+)** | **$20** | Viral referral dominant |

### CAC Reduction Drivers

1. **Brainiac Mastermind cohort model**: Every cohort member is incentivized to bring 3–5 peers. Viral coefficient >1.0 means the community self-replicates.

2. **Memory moat word-of-mouth**: As users' AI learns their business deeply, they tell peers. "My AI knows everything about my company" is a compelling referral story.

3. **True Bearing partnership**: 100K+ warm contacts from Corey Cottrell's network come at near-zero acquisition cost once the referral flywheel starts.

4. **Building in public**: Jared's LinkedIn/Bluesky documenting of PureBrain's development converts followers to sign-ups organically.

---

## LIFETIME VALUE (LTV)

### LTV Formula

LTV = ARPU × (1 / Monthly Churn Rate)

### LTV by Tier

| Tier | Monthly ARPU | Monthly Churn | Avg Lifetime (mo) | LTV |
|------|------------|-------------|-----------------|-----|
| Awakened | $197 | 4.5% | 22 months | $4,334 |
| Partnered | $579 | 3.0% | 33 months | $19,107 |
| Unified | $1,089 | 2.0% | 50 months | $54,450 |
| Enterprise | $10,000 | 1.5% | 67 months | $670,000 |

### Blended Consumer LTV

Weighted average at launch mix (72/20/8):
- **Blended LTV**: ~$14,400

---

## LTV:CAC RATIO

### Progression Over Time

| Period | LTV:CAC | Classification |
|--------|---------|---------------|
| Launch (Year 0) | 28:1 | Excellent |
| Year 1 | 92:1 | Exceptional |
| Year 2 | 92:1 | Exceptional |
| Year 3 | 225:1 | Best-in-class |
| Year 4 | 350:1 | Category-defining |
| Year 5 | 550:1 | Unprecedented |

**Industry benchmarks**:
- 3:1 = healthy SaaS
- 5:1 = good SaaS
- 10:1+ = exceptional SaaS
- 28:1 at launch = outstanding for any stage

### Why LTV:CAC Improves So Dramatically

1. **CAC drops**: Referral flywheel reduces acquisition cost from $150 → $20
2. **LTV increases**: Memory moat reduces churn rate from 4.2% → 2.5%
3. **Tier upgrades**: Users move from Awakened to Partnered/Unified as they get more value (increases ARPU without new acquisition cost)
4. **Enterprise conversion**: High-value users convert to enterprise contracts (LTV 150× higher than consumer)

---

## CHURN ANALYSIS

### Churn Rate Trajectory

| Period | Monthly Churn | Annual Churn |
|--------|-------------|-------------|
| Year 0 (Launch) | 4.2% | ~42% |
| Year 1 | 3.5% | ~35% |
| Year 2 | 3.5% | ~35% |
| Year 3 | 3.0% | ~31% |
| Year 4 | 2.8% | ~29% |
| Year 5 | 2.5% | ~26% |

### Why PureBrain Has Inverted Churn Dynamics

Traditional SaaS sees highest churn in Months 1–3 (before customers see value). PureBrain inverts this:

| Month | Memory Depth | Switching Cost |
|-------|-------------|--------------|
| Month 1 | Basic business context | Low |
| Month 3 | Product/service knowledge; key customers; active projects | Medium |
| Month 6 | Communication style; decision history; team dynamics; competitive intelligence | High |
| Month 12 | 12 months of decisions, outcomes, experiments, lessons learned | Very High |
| Month 24 | Irreplaceable institutional knowledge of your business | Extreme |

When a subscriber considers switching: they lose ALL accumulated business context, restart the 629% compound advantage from zero, and lose every past decision and lesson.

**Result**: Maximum churn in months 1–3 (before memory builds). Near-zero churn after month 6.

---

## GROSS MARGIN

### PureBrain Gross Margin Model

| Users | Monthly Revenue | Monthly AI/Infra Cost | Per-User Cost | Gross Margin |
|-------|----------------|----------------------|------------|------------|
| 100 | $34,476 | $2,500 | $25.00 | 92.7% |
| 1,000 | $344,760 | $18,000 | $18.00 | 94.8% |
| 10,000 | $3.45M | $120,000 | $12.00 | 96.5% |
| 100,000 | $34.5M | $700,000 | $7.00 | 98.0% |
| 1,000,000 | $345M | $3,500,000 | $3.50 | 99.0% |

**Note**: Financial model gross margins (78.9%→87.9%) include all operating costs, not just AI/infra. These are conservative EBITDA margins, not pure gross margins.

### What Drives Gross Margin Expansion

1. **Model optimization**: Intelligent routing between Claude Opus (complex) and Claude Sonnet (routine) reduces per-session cost without quality loss
2. **Bulk pricing**: Anthropic volume discounts at scale
3. **Infrastructure efficiency**: Cloudflare serverless means zero idle compute costs
4. **Amortization**: Fixed development costs spread over growing subscriber base

---

## PAYBACK PERIOD

| Period | CAC | Monthly Gross Profit/User | Payback Period |
|--------|-----|--------------------------|--------------|
| Launch | $150 | $272 (79% of $345) | 0.55 months |
| Year 3 | $20 | $293 (85% of $345) | 0.07 months |

**Context**: SaaS companies targeting <12 months payback are considered excellent. PureBrain's payback is measured in days at scale.

---

## NET REVENUE RETENTION (NRR)

| Period | NRR | Notes |
|--------|-----|-------|
| Launch | 107% | Tier upgrades more than offset churn |
| Year 1 | 118% | Strong expansion revenue from Awakened→Partnered moves |
| Year 3 | 125% | Enterprise upgrades at scale |

**NRR > 100%** means the existing subscriber base grows revenue even without adding new customers. This is the hallmark of the best SaaS companies (Snowflake, Datadog, Twilio).

---

## ENTERPRISE UNIT ECONOMICS

### Enterprise Tier

| Metric | Value |
|--------|-------|
| Average Contract Value | $10,000/month at launch |
| Range | $3,500–$25,000/month |
| Monthly Churn | 1.5% |
| Average Lifetime | 67 months |
| LTV | $670,000 |
| Enterprise CAC | ~$500 (sales-assisted) |
| Enterprise LTV:CAC | 1,340:1 |

### Enterprise Count Projection

| Year | Enterprise Clients | Enterprise Revenue |
|------|-----------------|------------------|
| Year 0 | 2 | $5M |
| Year 1 | 200 | $200M |
| Year 2 | 540 | $540M |
| Year 3 | 1,275 | $1.530B |
| Year 4 | 2,500 | $3.750B |
| Year 5 | 5,000+ | $7.500B |

---

## SUMMARY TABLE

| Metric | At Launch | Year 3 Target | Year 5 Target |
|--------|----------|--------------|--------------|
| Subscribers | ~100 | 5,400,000 | 12,900,000 |
| Blended ARPU | $345/mo | $345/mo | $345/mo |
| CAC | $150 | $20 | $12 |
| LTV:CAC | 28:1 | 225:1 | 550:1 |
| Gross Margin | 78.9% | 85.0% | 87.9% |
| Monthly Churn | 4.2% | 3.0% | 2.5% |
| Payback Period | ~0.55 mo | ~0.07 mo | ~0.04 mo |
| NRR | 107% | 125% | 130%+ |

---

*Pure Technology Inc. | March 2026 | Investor Data Room*
*Source: PT-Full-Financial-Model-WITH-PureBrainFINISHED.xlsx (March 19, 2026)*
