# Pure Marketing Group — Overview
## Pure Technology Inc. | Agency Division | March 2026

**Prepared**: March 2026
**Classification**: Investor Data Room — PMG Division

---

## OVERVIEW

Pure Marketing Group (PMG) is the revenue-generating agency division of Pure Technology Inc. It serves three strategic functions:

1. **Proof Engine**: Generates real client outcomes → case studies, benchmarks, playbooks that prove the PT thesis
2. **Distribution Engine**: Builds trust with brand decision-makers who will become DiMAP clients
3. **Bridge to Scale**: Prepares clients for Pure Influence and PureBrain adoption

**Revenue Range**: $3,500–$12,000/month client retainers

**Mission**: Unlock revenue for CPG, Tech, and Web3 brands by engineering personalized experiences that produce measurable ROI.

**Vision**: Create and own the category of "Personalized Experiential Marketing" — where brands grow by engineering fascination instead of buying attention.

**Core Differentiator**: "PMG doesn't chase attention; PMG engineers resonance."

---

## THE AGENCY MODEL

### Why PMG Exists Within Pure Technology

PMG is not simply a cash-flow vehicle. It is the manual-to-model bridge:

- **Manual phase (now)**: PMG delivers services by hand, learning what works
- **Automation phase (future)**: Best PMG processes get systematized into DiMAP and PureBrain
- **Scale phase**: Client relationships become DiMAP accounts; PMG graduates from agency to platform

This is a deliberate architectural decision. Every PMG engagement is both client service and product R&D.

### Anti-Drift Discipline

PMG must never become a permanent agency treadmill. The discipline:
- Continuously convert delivery into tighter niche moat
- Never expand capacity just to take on more clients
- Every new service offering must trace a path to productization

---

## SERVICE OFFERINGS

### 1. Experiential Giveaways

Personalized prize/experience campaigns that create viral shareability and emotional connection.

**How it works**:
- Brand defines target audience profile and campaign objective
- PMG designs an experience that generates authentic fascination (not purchased attention)
- Users opt-in through brand-aligned experiences
- Brand captures high-quality leads with real engagement history

**What it proves for PT**: The mechanism for opt-in consumer data collection at scale — the same mechanism DiMAP will automate.

### 2. Identity-Driven Influence

Creator ecosystems built on authentic identity alignment — not follower count alone.

**How it works**:
- PMG identifies influencers whose actual audience identity matches brand targets
- Campaigns are designed around shared values, not reach metrics
- Performance measured by conversion, not impressions
- Fraud eliminated through vetting and performance-based contracts

**What it proves for PT**: The influencer qualification model that Pure Influence will automate. PMG is building the playbook; Pure Influence will run it at scale.

### 3. LaunchBoost GTM Sequencing

Go-to-market frameworks that reduce launch confusion and accelerate adoption.

**How it works**:
- PMG maps the ideal customer journey from awareness to advocacy
- Sequences are designed to deliver core value within 48–72 hours of first contact
- Touchpoints are optimized by conversion data, not assumptions
- KPIs are set, tracked, and reported transparently

**What it proves for PT**: The same GTM philosophy will govern Pure Phone launch and PureBrain onboarding.

---

## CURRENT CLIENT BASE

### Active Recurring Clients (as of 2024)

| Client | Location | Service | Revenue |
|--------|----------|---------|---------|
| The Dog House Pet Salon | Houston, TX | Social Media Management | $32,090.91 LTV |
| Bethesda Spine and Posture | Bethesda, MD | Social Media Management | $34,321.11 LTV |
| MacSMP | White Plains, NY | Digital Marketing | $51,260.90 LTV |
| The Labz | Atlanta, GA | Social Media Management | $723.33 LTV |
| Alchemist Lifestyle | Miami, FL | Growth Hacking | $5,313.00 LTV |
| Terrapin Care Center | College Park, MD | Digital Marketing | $964.12 LTV |
| Level Small Plates | Annapolis, MD | Social Media Management | $482.06 LTV |

**PMG Recurring Revenue Summary**:
- Total Revenue: $77,609.25
- Total Cost: $63,161.25
- Profit: $14,448.00

### Previous Client History

| Client | Revenue | Duration |
|--------|---------|---------|
| Aescape (NYC) | $15,850 | 9 months |
| Suzanne Soliman | $14,961.03 | 1 year 10 months |
| Angel School (Singapore) | $17,024.64 | 9 months |
| Ruggerio Investments | $11,646.10 | 1 year |
| FitFCK (London) | $2,931.50 | 1 year 4 months |

**One-off deal revenue** (Jan 2023 – Jan 2024): $122,329.33

### Active Sales Pipeline (early 2024)

Total pending deals: $118,050

Top prospects:
- Pronovias (fashion): $100,000 US Digital Marketing Campaign
- Lenny Lomax / Ultimax Health: $2,600/month website & app development
- Seanne Murray: $2,500/month inspirational podcast
- Carter McQueen: $3,500 start + $2,500/month LinkedIn/Twitter management

---

## OUTCOMES DELIVERED (CLIENT PROMISE)

PMG commits to measurable outcomes — not activity metrics:

- Experiences that drive viral shareability and emotional connection
- Influencer ecosystems with higher trust and measurable conversion
- GTM frameworks that reduce confusion, accelerate adoption, and improve CAC
- Identity-led positioning that increases relevance, resonance, and retention
- Cross-channel experiences that outperform traditional media on cost and impact

---

## IDEAL CLIENT PROFILE

### Primary Target

CPG, beverage, beauty, wellness, lifestyle, and consumer brands that need to:
- Launch a product
- Break through a noisy category
- Modernize their growth strategy
- Build meaningful customer experiences
- Increase organic engagement

### Secondary Target

Tech, Web3, and gaming brands (casino and digital)

---

## METRICS THAT MATTER

PMG focuses on the metrics that matter to clients:

| Metric | Goal |
|--------|------|
| LTV (Lifetime Value) | Increase |
| CAC (Customer Acquisition Cost) | Decrease |
| ROI | Measurable, provable |

**Anti-pattern PMG avoids**: Media spend maximization ("quantity over quality" platforms). PMG's value is experience design + identity alignment + sequencing — not reach.

---

## PMG'S ROLE IN THE FULL PURE TECHNOLOGY PICTURE

PMG is strategically positioned between Pure Technology's current state and future scale:

| Now (PMG as Agency) | Later (Pure Technology at Scale) |
|--------------------|--------------------------------|
| Manual influencer vetting | Pure Influence automated scoring |
| Hand-crafted GTM strategies | DiMAP data-driven GTM automation |
| Individual client service | Platform self-service |
| $3.5K–$12K/month retainers | $197–$1,089/month SaaS |
| Learning what works | Productizing what works |

The PMG team's institutional knowledge — built through hundreds of client engagements — is the raw material for Pure Technology's product roadmap.

---

## PRICING

PMG standard retainer range: **$3,500–$12,000/month**

This range reflects:
- $3,500: Entry-level social media management and basic digital marketing
- $6,000–$8,000: Full-service campaigns with influencer management
- $10,000–$12,000: Comprehensive GTM execution with performance analytics

Enterprise/project-based engagements: Available ($100K+ projects documented in pipeline).

---

*Pure Technology Inc. | March 2026 | Investor Data Room*
