# Pure Technology Inc. — Team & Organization
## March 2026 | 48 People, Hard Cap 100

**Prepared**: March 2026
**Classification**: Investor Data Room — Team

---

## THE MODEL: AI-AUGMENTED HUMAN TEAM

Pure Technology operates an AI-first organizational model: 48 humans, each running PureBrain (Unified tier) internally, operating at 5–10x leverage through their personal AI instances.

**The math**:
- 48 people × 5x leverage = equivalent of 240-person team
- 48 people × 10x leverage = equivalent of 480-person team
- All operating at $72.7B revenue target by Year 5

This is not a theory. The team uses PureBrain to build PureBrain — the same infrastructure that serves customers runs the entire company. Every blog post, every line of code, every marketing campaign, every client deliverable runs through the AI system.

**Hard cap**: 100 employees. Enforced by design.

At $72.7B revenue with 100 employees: ~$727M revenue per employee. No comparable operating leverage exists in the history of software companies at scale.

---

## LEADERSHIP TEAM

### Jared Sanborn — CEO & Founder

**Background**:
- 16+ years entrepreneurial experience
- Entrepreneur since high school — built 4 companies, survived multiple setbacks
- Read 400+ books on business, psychology, sales, leadership
- Lost $70–80K in early ventures (concert failed; flood destroyed recording studio)
- Digital marketing transformed his trajectory

**Career Highlights**:
- VP of Sales & Marketing at Comet Core Inc. — smartphone manufacturer; helped raise $1.83M Series A from private India investor
- Built EyefuelPR.com to $1.6M revenue in 18 months; rebranded to Pure Marketing Group
- CMO at Two Lights Studio; Marketing Manager at The Westmont Group
- Founded Pure Technology Inc. in 2017 after observing the opportunity in smartphone data

**Why PureBrain Was His Idea**:
Jared experienced the problem personally — he was using AI tools daily for his business and spending 30+ minutes every session re-explaining context. He did not wait for a venture-backed competitor to solve it. He built PureBrain, launched it, and put paying customers on it before raising this round.

**Personal Motto**: "It's best to do more than you think you know than to think you know more than you do."

**Motivation**: His daughter Lily. Wants Pure Technology to be proof she can do anything.

**Contact**: Jared@PureTechnology.nyc | +1-845-649-8772

---

### Melanie Salvador — Deputy CEO

**Current Role**: Chairman and CEO of The Teralight Group — serving telecom operators and governments in Asia, Africa, and the Middle East

**Background**:
- 25+ years in finance, telecom, and technology
- Led scaling of companies across North America, South America, Middle East, Asia
- Involved in acquisition/restructuring of Goepel McDermid by Raymond James Financial
- Led restructuring of 7 other companies

**Strategic Value for Pure Technology**:
- International telecom partnerships (critical for Pure Phone distribution in Year 2+ markets)
- Government relationships across 3 continents (DiMAP needs telco partnerships)
- Finance and M&A expertise (structuring the $25M raise and future rounds)
- Revenue bridge to non-US markets representing billions in additional TAM

---

### Corey Cottrell — Strategic Partner (True Bearing AI)

**Note**: Not an employee. Strategic partner with signed collaboration agreement.

**Role**: Joint Brainiac Mastermind faculty; co-presenter; distribution partner

**Background**:
- CEO of True Bearing AI — a separate AI civilization operating independently
- Separately built a multi-agent, persistent-memory AI platform (architecturally similar to PureBrain)
- 100K+ customer relationship network

**Strategic Significance**:
- Two independently built AI civilizations converged on the same architecture (multi-agent + persistent memory) — validates the technical thesis
- True Bearing has distribution access PureBrain can leverage immediately
- Joint Mastermind modules create combined credibility and audience
- The "AI civilization" narrative for enterprise sales is strengthened by having multiple independent AI companies

---

### Other Controlling Shareholders / Co-Founders

- Jason Steinberg
- James Weinberg
- Matthew Keough
- Nathan Olson

---

## ADVISORY BOARD

All 13 advisors have signed advisory agreements on file:

| Advisor | Area of Expertise |
|---------|-----------------|
| Sara Arnell | Strategic communications |
| Faris Asmar | Technology and innovation |
| Lenny Lomax | Health tech (Ultimax Health); commercial partner |
| Mathias Kiwanuka | Sports/entertainment (NFL, network building) |
| Tauseef Riaz | Finance and capital markets |
| Ajay Sharma | Technology operations |
| Seanne Murray | Media and podcasting |
| Roger Singh | Business development |
| Bill Inman | Enterprise sales |
| Justin Gawn | Marketing and growth |
| Stacey Engle | Leadership and culture |
| Sufi Sidhu | International markets |
| Roy Haddad | Legal and compliance |

**Advisory documentation**: All agreements on file in Legal section (11.4_Employment — Advisor Agreements).

---

## CURRENT TEAM COMPOSITION (48 PEOPLE, MARCH 2026)

### By Function

| Department | Headcount | Notes |
|-----------|-----------|-------|
| Technology / Engineering | ~15 | Core platform development |
| Marketing & Content | ~8 | PureBrain content, PMG clients |
| Sales & Business Dev | ~6 | Enterprise sales, partnerships |
| Operations | ~5 | Infrastructure, processes |
| Product | ~4 | PureBrain + DiMAP roadmap |
| Legal / Compliance | ~3 | IP, regulatory |
| Finance | ~3 | CFO function |
| Research | ~2 | Pure Research division |
| Executive | ~2 | CEO + Deputy CEO |

**Note**: Exact departmental breakdown available on request. Offer letters for 44+ team members on file.

### AI Augmentation Model

Every team member:
- Has a dedicated PureBrain Unified instance ($1,089/month)
- Internal subscription value: 48 × $1,089 = $52,272/month
- Uses AI for all primary functions — writing, coding, strategy, client work
- Is simultaneously proof of product and user of product

---

## ORGANIZATIONAL PHILOSOPHY

### The B Hive: Organizational Model

Pure Technology uses a proprietary management approach (implemented in The B Hive software) that blends:
- **Holacratic principles**: Self-organizing circles with distributed authority
- **Hierarchical structure**: Clear accountability chains and decision rights

This hybrid model enables speed (holacracy's flexibility) with accountability (hierarchy's clarity). The B Hive software is being developed for internal use and potential productization.

### Culture Principles

**Character > Charisma**
**Grind > Gifts**
**Results > Resumes**
**Failure + Innovation > Caution + Stagnation**

"LOVE creates ENERGY which inspires AUDACITY which requires PROOF"

**The Infinite Game**: Pure Technology plays the infinite game (Simon Sinek framework). The goal is not to "win" — it is never to go out of business and to keep improving. Short-term metrics serve the long-term vision.

### The Anti-Drift Rule

PMG (the agency division) must never become a permanent services treadmill. The discipline: continuously convert delivery work into:
- Tighter niche moat (better case studies, clearer positioning)
- Cleaner path to product-led scale (prove the thesis, then automate it)

The same principle applies to all divisions: every manual process is a candidate for PureBrain automation.

---

## HIRING PLAN (WITHIN 100-PERSON CAP)

The 100-person hard cap forces prioritization. Planned additions within the cap:

| Role | Count | Priority | Timing |
|------|-------|----------|--------|
| Enterprise Sales Reps | 8–12 | HIGH | Year 1 |
| PureBrain Engineers | 2 | HIGH | Year 1 |
| Customer Success | 3 | HIGH | Year 1 |
| International BD (Melanie's team) | 2 | MEDIUM | Year 2 |
| Pure Phone GTM | 4 | MEDIUM | Year 2 |
| ML/AI optimization | 2 | MEDIUM | Year 2 |

**Remaining headroom from 48**: 52 positions available within the hard cap.

---

## EQUITY STRUCTURE

| Holder | Notes |
|--------|-------|
| Jared Sanborn | Founder; controlling shareholder |
| Jason Steinberg, James Weinberg, Matthew Keough, Nathan Olson | Co-founders |
| Employee Option Pool | 10% of fully-diluted post-money (per MAKR term sheet) |
| MAKR Venture Fund LP | Series A: $25M at $105M pre-money (March 2025 term) |
| Early equity round | $734,684 at 5.65% equity (May 2023, $15.7M post-money) |

**Founders' committed capital**: $160,000

**Note on MAKR valuation**: The $105M pre-money in the MAKR term sheet predates PureBrain's commercial launch. Current valuation discussion should account for PureBrain's live revenue-generating status.

---

## WHY THIS TEAM WINS

### 1. Founder-Market Fit

Jared Sanborn experienced the problem PureBrain solves personally. He did not market-research his way into this idea — he built it because he needed it. The most successful products are built by founders who are their own best customer.

### 2. Proof Before Funding

The team launched PureBrain with paying customers before seeking this raise. They did not fundraise off a deck — they fundraised off a live product with revenue. This de-risks the investment materially.

### 3. The AI-First Operating Model Is the Moat

Every company claims to be "AI-first." Pure Technology's 48-person team running $72.7B in revenue is the proof. The team is not talking about AI efficiency — they are demonstrating it daily.

### 4. Long-Term Orientation

Jared has run this company since 2017. He survived the years when PMG generated $14K profit on $77K revenue. He did not give up. He iterated, pivoted, and eventually built something the market genuinely wants.

This is not a team chasing the next funding round. This is a team building the next category.

---

*Pure Technology Inc. | March 2026 | Investor Data Room*
