# Pure Technology Inc. — Investment Terms
## Series A | MAKR Term Sheet | March 2026

**Prepared**: March 2026
**Classification**: Investor Data Room — Investment Terms

---

## THE ASK

**Seeking**: $25,000,000 USD (Series A Preferred Stock)

**Use of Funds**: Accelerate PureBrain subscriber acquisition + Pure Phone distribution (see breakdown below)

**What has changed since the term sheet**: PureBrain launched with paying customers on March 14, 2026. The $25M now accelerates a live, revenue-generating product — not an untested concept.

---

## ACTIVE TERM SHEET: MAKR VENTURE FUND LP

### Summary Terms

| Term | Detail |
|------|--------|
| Security Type | Series A Preferred Stock |
| Investor | MAKR Venture Fund LP |
| Investment Amount | **$25,000,000 USD** |
| Pre-Money Valuation | **$105,000,000 USD** |
| Post-Money Valuation | **$130,000,000 USD** |
| Price Per Share | $3.36/share (implied) |
| Employee Option Pool | 10% of fully-diluted post-money (included in pre-money) |
| Term Sheet Date | March 14, 2025 (SIGNED — redacted version in data room) |
| Governing Law | New York |
| Legal Counsel | Pierson Ferdinand UK LLP ("PF") |

### Conditions to Closing

1. Final approval by MAKR Investment Committee
2. Completion of final due diligence
3. Investment Committee agreement on pre-money valuation
4. Securities law compliance (Federal and State)
5. CFIUS clearance (or statement no further review needed)
6. Closing of MAKR funding round applicable to this funding
7. Satisfactory legal documentation
8. Legal opinions from the Company

**Source**: LC#3.IR-5-011-250317-Form of MAKR Termsheet_Pure Technology — SIGNED — redacted.pdf

---

## IMPORTANT NOTE: TERM SHEET PREDATES PUREBRAIN

The MAKR term sheet was executed March 14, 2025 — exactly one year before PureBrain launched commercially (March 14, 2026).

**What the $105M pre-money valuation was based on**:
- DiMAP / Pure Phone hardware platform (development stage)
- Pure Marketing Group agency revenue (~$77K recurring)
- 5-year revenue projection of $253.8M (Year 1) and $13.28B (Year 5) — old model

**What has materially changed since**:
- PureBrain has been developed, launched, and is generating revenue
- 5-year projection is now $3.962B (Year 1) and $72.698B (Year 5) — 15x and 5.5x higher
- Launch risk is eliminated — product is live with paying customers
- True Bearing partnership adds 100K+ warm customer relationships
- Brainiac Mastermind has 2 live modules with active cohorts

**Investor consideration**: The $105M pre-money valuation, while still available per the MAKR term, represents a significant discount to the company's current risk-adjusted value given the changes above. Both parties should discuss valuation in light of PureBrain's commercial launch.

---

## VALUATION ANALYSIS

### Historical Valuation Context

| Date | Event | Valuation |
|------|-------|-----------|
| May 2023 | Equity round | $15,734,684 post-money |
| Dec 2023 | Equidam valuation | $15.7M (early stage) |
| March 2025 | MAKR term sheet | $105M pre / $130M post |
| March 2026 | PureBrain launch | — (valuation discussion open) |

### Current Valuation Indicators

| Metric | Value | SaaS Industry Benchmark | Implied Valuation |
|--------|-------|------------------------|------------------|
| Year 1 ARR (PureBrain) | $2.24B | — | — |
| ARR × 5x (conservative) | — | 5x ARR = conservative | $11.2B |
| ARR × 10x (SaaS median) | — | 10x ARR = standard | $22.4B |
| ARR × 15x (high growth) | — | 15x ARR = premium growth | $33.6B |
| Year 1 EBITDA × 20x | $2.888B | — | $57.8B |

**Note**: Year 1 projections are model-based. Actual results depend on achieving 90-day subscriber milestones.

### Comparable SaaS Valuations at Revenue Scale

| Company | ARR at Series A | Valuation | Multiple |
|---------|----------------|-----------|---------|
| Snowflake (2020 IPO) | $592M | $33.2B | 56x ARR |
| HubSpot (2012) | $50M | $350M | 7x ARR |
| Salesforce (2004) | $50M | $400M | 8x ARR |
| **PureBrain Year 1** | **$2.24B** | $130M (MAKR terms) | **0.06x ARR** |

**Interpretation**: At MAKR terms, PureBrain is valued at 0.06x Year 1 ARR — 100x lower than comparable high-growth SaaS companies. This represents either a significant opportunity or a strong signal that valuation renegotiation is warranted.

---

## USE OF FUNDS

### Allocation of $25M

| Category | Amount | % | Description |
|----------|--------|---|-------------|
| PureBrain Subscriber Acquisition | $8M | 32% | Brainiac Mastermind expansion, LinkedIn Live, referral engine, content |
| Pure Phone Distribution | $6M | 24% | CPG partnership deals, MVNO negotiations, hardware subsidy |
| Engineering (within 100-cap) | $4M | 16% | Platform development, enterprise features, API |
| Enterprise Sales Team | $4M | 16% | 8–12 dedicated enterprise sales reps |
| International Expansion | $2M | 8% | EU, Middle East infrastructure via Melanie Salvador's network |
| Working Capital / Legal | $1M | 4% | Operating expenses, legal/compliance for Series A close |

### What This Capital Unlocks

**PureBrain acceleration (32% of funds)**:
- Brainiac Mastermind: Expand from 2 modules to 12+ by end of Year 1
- LinkedIn Live: Weekly live demonstrations driving organic sign-ups
- Referral engine: Systematize the viral coefficient already showing in early cohorts
- Projected outcome: 1.2M subscribers by Year 1 end (per financial model)

**Pure Phone distribution (24% of funds)**:
- 3–5 CPG brand partnerships (brands subsidize phone distribution)
- MVNO negotiations for carrier agreements in North America
- First 100K phones deployed by Year 1 end
- Projected outcome: $198.8M hardware subsidy revenue Year 1

**Engineering (16% of funds)**:
- Enterprise management console (multi-user, multi-department view)
- API access for enterprise customers
- Advanced BOOP scheduling visual builder
- Mobile native app (iOS/Android companion)

**Enterprise Sales (16% of funds)**:
- 8–12 dedicated enterprise reps targeting $10K–$25K/month contracts
- Sales playbook development
- Case study creation from early enterprise clients
- Target: 200 enterprise clients by Year 1 end ($200M enterprise revenue)

---

## INVESTOR PROTECTIONS AND RIGHTS

### Per MAKR Term Sheet

- **Series A Preferred Stock**: Standard preferences over common
- **Liquidation preference**: 1x non-participating (standard Series A)
- **Anti-dilution**: Weighted average (standard investor protection)
- **Board representation**: Per MAKR term sheet (details in signed document)
- **Information rights**: Standard quarterly and annual reporting
- **Pro-rata rights**: Follow-on investment participation rights

**Full terms**: See LC#3.IR-5-011-250317-Form of MAKR Termsheet_Pure Technology — SIGNED — redacted.pdf

---

## REGULATORY AND COMPLIANCE

### CFIUS

A CFIUS submission has been prepared and is included as a condition to closing. CFIUS review is required given:
- Foreign investor participation (MAKR Venture Fund LP — UK registered)
- Technology company with potential national security implications

**Status**: CFIUS filing prepared; awaiting closing process.

### Securities Law

- **Federal**: Exempt offering under Regulation D (private placement)
- **State**: Blue Sky compliance across relevant state jurisdictions
- **Counsel**: Pierson Ferdinand UK LLP engaged for securities compliance

### Prior Equity Round

| Detail | Value |
|--------|-------|
| Type | Equity Round |
| Date | May 1, 2023 |
| Post-Money Valuation | $15,734,684 |
| Investment | $734,684 |
| Equity % | 5.65% |

**Founder committed capital**: $160,000

---

## THE INVESTMENT OPPORTUNITY IN PLAIN TERMS

Pure Technology is raising $25M to:

1. **Scale a live product** (PureBrain) from ~100 paying customers to 1.2M subscribers
2. **Launch a hardware platform** (Pure Phone) through CPG partnerships
3. **Hire an enterprise sales team** to close $10K–$25K/month contracts

The company is not asking investors to fund a proof of concept. It is asking investors to fund the scaling of a product that is already working.

**The risk profile as of March 2026**:
- Product risk: Eliminated (PureBrain is live with paying customers)
- Technical risk: Low (birth pipeline E2E verified; portal shipped with 17/17 QA tests passing)
- Market risk: Reduced (actual customer traction proves the problem is real and the solution works)
- Remaining risk: Execution at scale — can the team acquire 1.2M subscribers in Year 1?

**The upside**:
- Year 1 PureBrain ARR: $2.24B
- Year 5 Consolidated Revenue: $72.7B
- Year 5 EBITDA: $52.4B

At MAKR terms ($130M post-money), an investor acquires $25M/$130M = 19.2% of a company projecting $52.4B EBITDA by Year 5.

---

*Pure Technology Inc. | March 2026 | Investor Data Room*
*Term sheet source: LC#3.IR-5-011-250317-Form of MAKR Termsheet — SIGNED — redacted.pdf*
