# PureBrain Pay-Test 2 - Full Code Package

**Page**: https://purebrain.ai/pay-test-2/
**Page ID**: 689
**Slug**: pay-test-2
**Status**: Published (password protected)
**Password**: PureBrain.ai253443$$$
**Template**: elementor_canvas
**Extracted**: 2026-02-22

---

## Package Contents

### Root Files
| File | Description |
|------|-------------|
| `page689_full_api_response.json` | Complete WP REST API response (1.2MB, everything) |
| `page689_elementor_data.json` | Elementor page builder data (440KB, all widgets/sections) |
| `page689_rendered.html` | Full rendered HTML from WordPress (384KB) |
| `page689_metadata.json` | WordPress metadata: slug, status, template, password, URLs |
| `page689_all_meta.json` | All WordPress custom meta fields (Yoast SEO, Elementor settings, etc.) |
| `README.md` | This file |

### `/scripts/` - JavaScript Files (13 total)
| File | Size | Description |
|------|------|-------------|
| `script-01-main-page.js` | 57KB | **PRE-PAYMENT page JS** - canvas animation, video bg, orbs, mouse glow, scroll progress, awakening sequence, pricing reveal |
| `script-01-main-page-v2.js` | 12KB | SG Speed Optimizer / WP Analytics tracking script |
| `script-paypal-popup-integration.js` | 31KB | **PayPal SDK integration** - LIVE environment (different client ID vs sandbox) |
| `script-pay-test-chat-flow-v2.js` | 46KB | **POST-PAYMENT CHAT FLOW v2** - questionnaire, curtain reveal, Telegram setup, Claude Max walkthrough, completion flow |
| `script-integration-glue.js` | 4KB | **Wires PayPal → Chat** - `window.onPaymentComplete`, `launchPostPaymentFlow`, URL return detection |
| `script-paypal-popup-integration-v2.js` | 811 bytes | PayPal SDK loader script tag |
| `script-elementor-05.js` | 2.7KB | Elementor frontend JS |
| `script-elementor-08.js` | 1KB | Elementor modules init |
| `script-01-unknown.js` | 2.3KB | Browser detection / feature detection |
| `script-03-unknown.js` | 377 bytes | Small inline script |
| `script-06-unknown.js` | 244 bytes | Small inline script |
| `script-07-unknown.js` | 3KB | WordPress nonce / AJAX config |
| `script-09-unknown.js` | 589 bytes | Small inline script |

### `/styles/` - CSS Files (6 total)
| File | Size | Description |
|------|------|-------------|
| `style-04.css` | 9.3KB | Page-level custom CSS variables, layout |
| `style-05.css` | 49KB | Main component styles (chat, pricing, animations) |
| `style-06.css` | 72KB | Full Elementor-generated page styles |
| `style-01.css` | 133 bytes | Small inline style |
| `style-02.css` | 340 bytes | Small inline style |
| `style-03.css` | 348 bytes | Small inline style |

### `/elementor-widget-scripts/` - Raw Elementor Widget Code
Same scripts as extracted from Elementor JSON

---

## Key Architecture Notes for Corey/AICIV

### Payment Flow Architecture
```
User arrives → Pre-payment page (script-01-main-page.js)
    ↓
"Discover PureBrain" → Pricing reveal
    ↓
PayPal button click → Popup opens (script-paypal-popup-integration.js)
    ↓
Payment complete → window.onPaymentComplete() (script-integration-glue.js)
    ↓
Post-payment chat launched → initPayTestFlow() (script-pay-test-chat-flow-v2.js)
    ↓
Questionnaire → Behind-the-Curtain → Telegram → Claude Max → Complete
```

### CSS Variables Used
```css
--bright-orange: #f1420b
--light-blue: #2a93c1
--dark: #0a0a0a
```

### Critical Functions
- `window.initPayTestFlow(chatContainer, aiName, tierPaid)` - starts post-payment flow
- `window.onPaymentComplete(tier, orderId, payerInfo)` - PayPal success callback
- `window._pbState.aiName` - AI name state store
- `window.pbAiName` - fallback AI name

### Logging Endpoints
The v2 flow logs to:
- `POST /api/log-pay-test` - payment events
- `POST /api/log-conversation` - conversation events

---

## Note: This is LIVE (pay-test-2) vs Sandbox (pay-test-sandbox-2)
This page uses the live PayPal client ID. The sandbox version (package-sandbox-2) uses the PayPal sandbox client ID. The only code difference is in `script-paypal-popup-integration.js` (51 bytes larger in this live version).

