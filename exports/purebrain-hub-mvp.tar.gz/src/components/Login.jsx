import React, { useState } from 'react'
import { useToast } from '../App.jsx'

// Demo users - in production these come from the server
const DEMO_USERS = [
  { token: 'team2025', name: 'Jared Sanborn', role: 'Admin', department: 'Leadership' },
  { token: 'safety2025', name: 'Sarah K.', role: 'Safety Lead', department: 'Operations' },
  { token: 'quality2025', name: 'Marcus T.', role: 'Quality Manager', department: 'Quality' },
  { token: 'demo', name: 'Demo User', role: 'Member', department: 'General' },
]

export default function Login({ onLogin }) {
  const [token, setToken] = useState('')
  const [name, setName] = useState('')
  const [useToken, setUseToken] = useState(true)
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const addToast = useToast()

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError('')
    setLoading(true)

    await new Promise(r => setTimeout(r, 600)) // Simulate auth check

    if (useToken) {
      const user = DEMO_USERS.find(u => u.token === token.trim().toLowerCase())
      if (user) {
        onLogin(user)
      } else {
        setError('Invalid access token. Try: team2025 | safety2025 | demo')
      }
    } else {
      if (name.trim().length < 2) {
        setError('Please enter your name (2+ characters)')
        setLoading(false)
        return
      }
      onLogin({
        name: name.trim(),
        role: 'Member',
        department: 'General',
        token: 'guest'
      })
    }
    setLoading(false)
  }

  return (
    <div className="login-page">
      <div className="login-card">
        <div className="login-logo">
          <div className="logo-icon-lg">PB</div>
          <h1>
            <span style={{ color: 'var(--pb-blue)' }}>PUREBR</span>
            <span style={{ color: 'var(--pb-orange)' }}>AI</span>
            <span style={{ color: 'var(--pb-blue)' }}>N</span>
          </h1>
          <p>Team Engagement Hub</p>
        </div>

        {error && <div className="login-error">{error}</div>}

        <form onSubmit={handleSubmit}>
          {useToken ? (
            <div className="form-group">
              <label className="form-label">Access Token</label>
              <input
                type="text"
                className="form-input"
                placeholder="Enter your team access token"
                value={token}
                onChange={e => setToken(e.target.value)}
                autoFocus
              />
              <div style={{ fontSize: '12px', color: 'var(--text-muted)', marginTop: '6px' }}>
                Demo tokens: <code style={{ color: 'var(--pb-blue)' }}>team2025</code> · <code style={{ color: 'var(--pb-blue)' }}>demo</code>
              </div>
            </div>
          ) : (
            <div className="form-group">
              <label className="form-label">Your Name</label>
              <input
                type="text"
                className="form-input"
                placeholder="Enter your full name"
                value={name}
                onChange={e => setName(e.target.value)}
                autoFocus
              />
            </div>
          )}

          <button
            type="submit"
            className="btn btn-primary"
            style={{ width: '100%', justifyContent: 'center', marginBottom: '12px' }}
            disabled={loading}
          >
            {loading ? <><span className="spinner" style={{ width: 16, height: 16 }}></span> Verifying...</> : 'Access Hub'}
          </button>

          <button
            type="button"
            className="btn btn-ghost btn-sm"
            style={{ width: '100%', justifyContent: 'center' }}
            onClick={() => { setUseToken(!useToken); setError('') }}
          >
            {useToken ? 'Join as Guest (no token)' : 'Use access token instead'}
          </button>
        </form>

        <div className="divider" />

        <div style={{ textAlign: 'center' }}>
          <p style={{ fontSize: '12px', color: 'var(--text-muted)' }}>
            Share wins. Celebrate achievements. Drive improvement.<br />
            <span style={{ color: 'var(--pb-blue)' }}>PureBrain Team Hub v0.1 MVP</span>
          </p>
        </div>
      </div>
    </div>
  )
}
