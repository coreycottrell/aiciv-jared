#!/bin/bash
# portal_send_file.sh — Send a file into the portal chat as an Aether message
# Usage: ./portal_send_file.sh /path/to/file.md "Optional caption message"
# Usage: ./portal_send_file.sh --text "Just a text message, no file"

set -euo pipefail

UPLOADS_DIR="$HOME/portal_uploads"
CHAT_JSONL="$HOME/purebrain_portal/portal-chat.jsonl"

# Text-only mode
if [ "${1:-}" = "--text" ]; then
  shift
  TEXT="$*"
  TIMESTAMP=$(date +%s)
  ID="portal-file-${TIMESTAMP}-${RANDOM}"
  printf '{"role":"assistant","text":"%s","timestamp":%s,"id":"%s"}\n' \
    "$(echo "$TEXT" | sed 's/"/\\"/g' | sed ':a;N;$!ba;s/\n/\\n/g')" \
    "$TIMESTAMP" "$ID" >> "$CHAT_JSONL"
  echo "Sent text to portal chat"
  exit 0
fi

FILE_PATH="${1:?Usage: portal_send_file.sh /path/to/file [caption]}"
CAPTION="${2:-}"

if [ ! -f "$FILE_PATH" ]; then
  echo "Error: File not found: $FILE_PATH" >&2
  exit 1
fi

# Copy file to uploads dir with timestamp prefix
ORIGINAL_NAME=$(basename "$FILE_PATH")
STORED_NAME="$(date +%s%3N)_${ORIGINAL_NAME}"
cp "$FILE_PATH" "${UPLOADS_DIR}/${STORED_NAME}"

# Determine file type for display
EXT="${ORIGINAL_NAME##*.}"
case "$EXT" in
  md)   ICON="📄" ; TYPE="Markdown" ;;
  html) ICON="🌐" ; TYPE="HTML" ;;
  pdf)  ICON="📕" ; TYPE="PDF" ;;
  png|jpg|jpeg|gif|webp) ICON="🖼️" ; TYPE="Image" ;;
  csv)  ICON="📊" ; TYPE="CSV" ;;
  json) ICON="📋" ; TYPE="JSON" ;;
  *)    ICON="📎" ; TYPE="File" ;;
esac

# Build message text
TIMESTAMP=$(date +%s)
ID="portal-file-${TIMESTAMP}-${RANDOM}"

if [ -n "$CAPTION" ]; then
  MSG_TEXT="${CAPTION}\\n\\n${ICON} **${ORIGINAL_NAME}**\\n[PORTAL_FILE:${STORED_NAME}:${ORIGINAL_NAME}]"
else
  MSG_TEXT="${ICON} **${ORIGINAL_NAME}**\\n[PORTAL_FILE:${STORED_NAME}:${ORIGINAL_NAME}]"
fi

# Write to JSONL
printf '{"role":"assistant","text":"%s","timestamp":%s,"id":"%s"}\n' \
  "$MSG_TEXT" "$TIMESTAMP" "$ID" >> "$CHAT_JSONL"

echo "File sent to portal chat: ${ORIGINAL_NAME} (stored as ${STORED_NAME})"
