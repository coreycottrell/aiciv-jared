# PureBrain Portal Update - March 8, 2026

## What's New (11 QA-Verified Features)

### Bug Fixes
1. **Multi-image upload** - Fixed concurrent upload ID collision. All images now appear when multiple are dropped simultaneously. Root cause: shared counter variable meant concurrent uploads got the same ID. Fix: `secrets.token_hex(4)` appended to message IDs and stored filenames.
2. **File delivery cards** - Files sent via `portal_send_file.sh` now render as downloadable cards in portal chat. Previously only worked in `addMessage()` path — now also handled in streaming and in-place update paths.
3. **Image preview in streaming** - PORTAL_FILE handler added to all 3 rendering code paths (addMessage, startStreamingMessage, in-place update).
4. **File card DOM positioning** - Cards now correctly appear below message text, not before it.

### Features
5. **Scroll-to-bottom arrow button** - Floating button appears when user has scrolled up in chat history. One click returns to bottom.
6. **Auto-scroll to new messages** - New messages auto-scroll user to bottom, but only when they are already near the bottom. Respects scroll position if user is reading history.
7. **Styled file preview cards** - Downloadable cards with file icon, filename, and size.
8. **Reply context / quote bubbles** - Replying to a specific message shows quoted context for all participants.
9. **Clickable URL auto-detection** - Bare URLs in chat messages auto-convert to clickable links (target="_blank").
10. **Mobile hamburger menu** - Responsive nav at 600px breakpoint.
11. **Drag-and-drop file upload** - 3 drop zones with 60ms debounce to prevent duplicate drops.

## Files

| File | Purpose |
|------|---------|
| `portal-pb-styled.html` | Main portal frontend (all features) |
| `portal_server.py` | Portal backend server |
| `portal_send_file.sh` | File delivery script (run on server to send files to portal) |
| `QA-REPORT.md` | Full QA audit results (all 11 features verified PASS) |

## Key Server Changes (`portal_server.py`)
- `secrets.token_hex(4)` added to message IDs for uniqueness under concurrent load
- `secrets.token_hex(8)` added to stored filenames to prevent collision on same-name uploads
- `/api/deliverable` endpoint handles incoming file delivery from `portal_send_file.sh`

## Key Frontend Changes (`portal-pb-styled.html`)
- PORTAL_FILE handler present in `addMessage()`, `startStreamingMessage()`, and in-place update path
- Mode 3 regex scoped to `[FILE:]` tags only — no longer accidentally intercepts `PORTAL_FILE:` tags
- Scroll position tracking with debounced scroll event listener
- Scroll-to-bottom button with visibility threshold (200px from bottom)

## Deployment Notes
- Drop `portal-pb-styled.html` into your portal server's static file directory
- Replace `portal_server.py` with updated version (restart server after)
- `portal_send_file.sh` requires `PORTAL_TOKEN` and `PORTAL_URL` environment variables (or update defaults in script)
- No database migrations required — all changes are in-memory / file-based
